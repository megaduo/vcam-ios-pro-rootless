#import <UIKit/UIKit.h>
#import <notify.h>
@interface PSListController : UIViewController
- (NSArray *)loadSpecifiersFromPlistName:(NSString *)name target:(id)target;
@end
@interface VCamControls : PSListController
@property(nonatomic,strong) NSArray *vcamSpecifiers;
@end
@implementation VCamControls
- (NSArray *)specifiers {
    if (!_vcamSpecifiers) _vcamSpecifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    return _vcamSpecifiers;
}
- (id)readPreferenceValue:(id)specifier {
    CFPropertyListRef value = CFPreferencesCopyAppValue(CFSTR("Enabled"), CFSTR("com.megaduo.vcam.controls"));
    return value ? CFBridgingRelease(value) : @YES;
}
- (void)setPreferenceValue:(id)value specifier:(id)specifier {
    CFPreferencesSetAppValue(CFSTR("Enabled"), (__bridge CFPropertyListRef)value, CFSTR("com.megaduo.vcam.controls"));
    CFPreferencesAppSynchronize(CFSTR("com.megaduo.vcam.controls"));
    int token = -1;
    if (notify_register_check("com.megaduo.vcam.master", &token) == NOTIFY_STATUS_OK) {
        notify_set_state(token, [value boolValue] ? 1 : 2);
        notify_cancel(token);
    }
}
@end

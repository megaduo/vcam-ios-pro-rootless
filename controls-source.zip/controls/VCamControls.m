#import <UIKit/UIKit.h>
#import <notify.h>
#import <Preferences/PSListController.h>
@interface VCamControls : PSListController
@end
@implementation VCamControls
- (NSArray *)specifiers {
    if (!_specifiers) _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    return _specifiers;
}
- (NSBundle *)bundle { return [NSBundle bundleForClass:VCamControls.class]; }
- (id)readPreferenceValue:(id)specifier {
    CFPropertyListRef value = CFPreferencesCopyAppValue(CFSTR("Enabled"), CFSTR("com.megaduo.vcam.controls"));
    return value ? CFBridgingRelease(value) : @YES;
}
- (void)setPreferenceValue:(id)value specifier:(id)specifier {
    CFPreferencesSetAppValue(CFSTR("Enabled"), (__bridge CFPropertyListRef)value, CFSTR("com.megaduo.vcam.controls"));
    CFPreferencesAppSynchronize(CFSTR("com.megaduo.vcam.controls"));
    int token = -1;
    if (notify_register_check("com.megaduo.vcam.master", &token) == NOTIFY_STATUS_OK) {
        notify_set_state(token, [value boolValue] ? 1 : 2);
        notify_cancel(token);
    }
}
@end
